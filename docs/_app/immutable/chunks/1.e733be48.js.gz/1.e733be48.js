import{default as t}from"../entry/error.svelte.bd11ae4d.js";export{t as component};
