import{default as t}from"../entry/_page.svelte.557636cc.js";export{t as component};
