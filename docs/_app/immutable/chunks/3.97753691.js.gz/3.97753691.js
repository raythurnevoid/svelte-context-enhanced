import{default as t}from"../entry/typed-key-page.svelte.4d1f48fc.js";export{t as component};
